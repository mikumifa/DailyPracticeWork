#ifndef SOLUTION_HPP
#define SOLUTION_HPP
#include <utility>

std::pair<unsigned int, int> ExponentToOverflow(int init_value,
                                                unsigned int base);

#endif
